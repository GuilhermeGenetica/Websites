SeqNode Agent — Python Package
==============================

Requirements
------------
Python 3.10+  (https://www.python.org/downloads/)
pip (included with Python)

Quick Start (Linux / macOS)
---------------------------
1.  Extract this zip into any folder, e.g. ~/seqnode-agent/
2.  Install dependencies:
        pip install websockets psutil
3.  Initialize (replace YOUR_TOKEN with the token from
    Settings > Agent > Token):
        python agent.py init \
          --server wss://api.seqnode.onnetweb.com/ws/agent \
          --token  YOUR_TOKEN \
          --workspace ~/seqnode-workspace
4.  Start:
        python agent.py start          # foreground (shows logs)
        python agent.py start --daemon # background daemon

Management commands:
        python agent.py status
        python agent.py stop

Quick Start (Windows — cmd.exe)
--------------------------------
1.  Extract this zip into any folder, e.g. C:\seqnode-agent\
2.  Install dependencies:
        pip install websockets psutil
3.  Initialize:
        python agent.py init --server wss://api.seqnode.onnetweb.com/ws/agent --token YOUR_TOKEN --workspace %USERPROFILE%\seqnode-workspace
4.  Start:
        python agent.py start
    Or minimised window:
        start /min python agent.py start
    Or on login via Task Scheduler:
        schtasks /create /tn "SeqNodeAgent" /tr "python C:\seqnode-agent\agent.py start" /sc onlogon /ru %USERNAME% /f

Files
-----
agent.py      Main entry point and CLI
config.py     Configuration (~/.seqnode-agent/config.json)
executor.py   Subprocess runner with real-time log streaming
monitor.py    CPU / RAM / disk snapshot (requires psutil)
security.py   HMAC command validation and workspace sandbox
ws_client.py  WebSocket client with auto-reconnect

How It Works
------------
The agent opens an outbound WebSocket connection to the SeqNode
server — no open ports or firewall rules needed on your machine.
Commands received from the server are HMAC-signed and verified
before execution. All file access is sandboxed to the workspace
directory you configure.

More info: https://seqnode.onnetweb.com/help
